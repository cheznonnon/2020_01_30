// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_UXTHEME
#define _H_NONNON_WIN32_UXTHEME




#include "../neutral/posix.c"

#include "./win/darkmode.c"
#include "./win/font.c"

#include "./sysinfo/version.c"




#include <uxtheme.h>


// [!] : these headers may have the same symbols

// [x] : MinGW : tmschema.h : many symbols are missing
// [x] : MinGW :  vsstyle.h : this file is missing
// [x] : MinGW :  vssym32.h : this file is missing

//#include <tmschema.h>

#ifdef _MSC_VER


#include <vsstyle.h>
#include <vssym32.h>


#else  // #ifdef _MSC_VER


// [Patch] : MinGW : missing symbols


#define HPAINTBUFFER     HANDLE
#define HANIMATIONBUFFER HANDLE


#define TMT_TRANSITIONDURATIONS 6000

#define SPI_GETCLIENTAREAANIMATION 0x1042


typedef enum _BP_BUFFERFORMAT {

	BPBF_COMPATIBLEBITMAP,
	BPBF_DIB,
	BPBF_TOPDOWNDIB,
	BPBF_TOPDOWNMONODIB

} BP_BUFFERFORMAT;


#define BPPF_ERASE     0x0001
#define BPPF_NOCLIP    0x0002
#define BPPF_NONCLIENT 0x0004

typedef struct _BP_PAINTPARAMS {

	DWORD cbSize;
	DWORD dwFlags;
	const RECT *prcExclude;
	const BLENDFUNCTION *pBlendFunction;

} BP_PAINTPARAMS, *PBP_PAINTPARAMS;


typedef enum _BP_ANIMATIONSTYLE {

	BPAS_NONE,
	BPAS_LINEAR,
	BPAS_CUBIC,
	BPAS_SINE

} BP_ANIMATIONSTYLE;


typedef struct _BP_ANIMATIONPARAMS {

	DWORD cbSize;
	DWORD dwFlags;
	BP_ANIMATIONSTYLE style;
	DWORD dwDuration;

} BP_ANIMATIONPARAMS, *PBP_ANIMATIONPARAMS;



#define DTT_TEXTCOLOR     ( 1 <<  0 )
#define DTT_BORDERCOLOR   ( 1 <<  1 )
#define DTT_SHADOWCOLOR   ( 1 <<  2 )
#define DTT_SHADOWTYPE    ( 1 <<  3 )
#define DTT_SHADOWOFFSET  ( 1 <<  4 )
#define DTT_BORDERSIZE    ( 1 <<  5 )
#define DTT_FONTPROP      ( 1 <<  6 )
#define DTT_COLORPROP     ( 1 <<  7 )
#define DTT_STATEID       ( 1 <<  8 )
#define DTT_CALCRECT      ( 1 <<  9 )
#define DTT_APPLYOVERLAY  ( 1 << 10 )
#define DTT_GLOWSIZE      ( 1 << 11 )
#define DTT_CALLBACK      ( 1 << 12 )
#define DTT_COMPOSITED    ( 1 << 13 )
#define DTT_VALIDBITS     ( 0x1fff  )

typedef int (WINAPI *DTT_CALLBACK_PROC)( HDC hdc, LPWSTR pszText, int cchText, LPRECT prc, UINT dwFlags, LPARAM lParam );

enum TEXTSHADOWTYPE
{
	TST_NONE       = 0,
	TST_SINGLE     = 1,
	TST_CONTINUOUS = 2,
};

typedef struct _DTTOPTS {

	DWORD             dwSize;
	DWORD             dwFlags;
	COLORREF          crText;
	COLORREF          crBorder;
	COLORREF          crShadow;
	int               iTextShadowType;
	POINT             ptShadowOffset;
	int               iBorderSize;
	int               iFontPropId;
	int               iColorPropId;
	int               iStateId;
	BOOL              fApplyOverlay;
	int               iGlowSize;
	DTT_CALLBACK_PROC pfnDrawTextCallback;
	LPARAM            lParam;

} DTTOPTS, *PDTTOPTS;


#ifndef __VSSTYLE_H__


#define VSCLASS_BUTTONSTYLE  L"BUTTONSTYLE"
#define VSCLASS_BUTTON       L"BUTTON"

enum BUTTONPARTS
{
	BP_PUSHBUTTON       = 1,
	BP_RADIOBUTTON      = 2,
	BP_CHECKBOX         = 3,
	BP_GROUPBOX         = 4,
	BP_USERBUTTON       = 5,
	BP_COMMANDLINK      = 6,
	BP_COMMANDLINKGLYPH = 7,
};

#define BUTTONSTYLEPARTS BUTTONPARTS;

enum PUSHBUTTONSTATES
{
	PBS_NORMAL              = 1,
	PBS_HOT                 = 2,
	PBS_PRESSED             = 3,
	PBS_DISABLED            = 4,
	PBS_DEFAULTED           = 5,
	PBS_DEFAULTED_ANIMATING = 6,
};

enum RADIOBUTTONSTATES
{
	RBS_UNCHECKEDNORMAL   = 1,
	RBS_UNCHECKEDHOT      = 2,
	RBS_UNCHECKEDPRESSED  = 3,
	RBS_UNCHECKEDDISABLED = 4,
	RBS_CHECKEDNORMAL     = 5,
	RBS_CHECKEDHOT        = 6,
	RBS_CHECKEDPRESSED    = 7,
	RBS_CHECKEDDISABLED   = 8,
};

enum CHECKBOXSTATES
{
	CBS_UNCHECKEDNORMAL   =  1,
	CBS_UNCHECKEDHOT      =  2,
	CBS_UNCHECKEDPRESSED  =  3,
	CBS_UNCHECKEDDISABLED =  4,
	CBS_CHECKEDNORMAL     =  5,
	CBS_CHECKEDHOT        =  6,
	CBS_CHECKEDPRESSED    =  7,
	CBS_CHECKEDDISABLED   =  8,
	CBS_MIXEDNORMAL       =  9,
	CBS_MIXEDHOT          = 10,
	CBS_MIXEDPRESSED      = 11,
	CBS_MIXEDDISABLED     = 12,
	CBS_IMPLICITNORMAL    = 13,
	CBS_IMPLICITHOT       = 14,
	CBS_IMPLICITPRESSED   = 15,
	CBS_IMPLICITDISABLED  = 16,
	CBS_EXCLUDEDNORMAL    = 17,
	CBS_EXCLUDEDHOT       = 18,
	CBS_EXCLUDEDPRESSED   = 19,
	CBS_EXCLUDEDDISABLED  = 20,
};

enum GROUPBOXSTATES
{
	GBS_NORMAL   = 1,
	GBS_DISABLED = 2,
};

enum COMMANDLINKSTATES
{
	CMDLS_NORMAL              = 1,
	CMDLS_HOT                 = 2,
	CMDLS_PRESSED             = 3,
	CMDLS_DISABLED            = 4,
	CMDLS_DEFAULTED           = 5,
	CMDLS_DEFAULTED_ANIMATING = 6,
};

enum COMMANDLINKGLYPHSTATES
{
	CMDLGS_NORMAL    = 1,
	CMDLGS_HOT       = 2,
	CMDLGS_PRESSED   = 3,
	CMDLGS_DISABLED  = 4,
	CMDLGS_DEFAULTED = 5,
};


#define VSCLASS_EDITSTYLE  L"EDITSTYLE"
#define VSCLASS_EDIT       L"EDIT"

enum EDITPARTS
{
	EP_EDITTEXT             = 1,
	EP_CARET                = 2,
	EP_BACKGROUND           = 3,
	EP_PASSWORD             = 4,
	EP_BACKGROUNDWITHBORDER = 5,
	EP_EDITBORDER_NOSCROLL  = 6,
	EP_EDITBORDER_HSCROLL   = 7,
	EP_EDITBORDER_VSCROLL   = 8,
	EP_EDITBORDER_HVSCROLL  = 9,
};

#define EDITSTYLEPARTS EDITPARTS;

enum EDITTEXTSTATES
{
	ETS_NORMAL    = 1,
	ETS_HOT       = 2,
	ETS_SELECTED  = 3,
	ETS_DISABLED  = 4,
	ETS_FOCUSED   = 5,
	ETS_READONLY  = 6,
	ETS_ASSIST    = 7,
	ETS_CUEBANNER = 8,
};

enum BACKGROUNDSTATES
{
	EBS_NORMAL   = 1,
	EBS_HOT      = 2,
	EBS_DISABLED = 3,
	EBS_FOCUSED  = 4,
	EBS_READONLY = 5,
	EBS_ASSIST   = 6,
};

enum BACKGROUNDWITHBORDERSTATES
{
	EBWBS_NORMAL   = 1,
	EBWBS_HOT      = 2,
	EBWBS_DISABLED = 3,
	EBWBS_FOCUSED  = 4,
};

enum EDITBORDER_NOSCROLLSTATES
{
	EPSN_NORMAL   = 1,
	EPSN_HOT      = 2,
	EPSN_FOCUSED  = 3,
	EPSN_DISABLED = 4,
};

enum EDITBORDER_HSCROLLSTATES
{
	EPSH_NORMAL   = 1,
	EPSH_HOT      = 2,
	EPSH_FOCUSED  = 3,
	EPSH_DISABLED = 4,
};

enum EDITBORDER_VSCROLLSTATES
{
	EPSV_NORMAL   = 1,
	EPSV_HOT      = 2,
	EPSV_FOCUSED  = 3,
	EPSV_DISABLED = 4,
};

enum EDITBORDER_HVSCROLLSTATES
{
	EPSHV_NORMAL   = 1,
	EPSHV_HOT      = 2,
	EPSHV_FOCUSED  = 3,
	EPSHV_DISABLED = 4,
};


#define VSCLASS_PROGRESSSTYLE  L"PROGRESSSTYLE"
#define VSCLASS_PROGRESS       L"PROGRESS"

enum PROGRESSPARTS
{
	PP_BAR                =  1,
	PP_BARVERT            =  2,
	PP_CHUNK              =  3,
	PP_CHUNKVERT          =  4,
	PP_FILL               =  5,
	PP_FILLVERT           =  6,
	PP_PULSEOVERLAY       =  7,
	PP_MOVEOVERLAY        =  8,
	PP_PULSEOVERLAYVERT   =  9,
	PP_MOVEOVERLAYVERT    = 10,
	PP_TRANSPARENTBAR     = 11,
	PP_TRANSPARENTBARVERT = 12,
};

#define PROGRESSSTYLEPARTS PROGRESSPARTS;

enum TRANSPARENTBARSTATES
{
	PBBS_NORMAL  = 1,
	PBBS_PARTIAL = 2,
};

enum TRANSPARENTBARVERTSTATES
{
	PBBVS_NORMAL  = 1,
	PBBVS_PARTIAL = 2,
};

enum FILLSTATES
{
	PBFS_NORMAL  = 1,
	PBFS_ERROR   = 2,
	PBFS_PAUSED  = 3,
	PBFS_PARTIAL = 4,
};

enum FILLVERTSTATES
{
	PBFVS_NORMAL  = 1,
	PBFVS_ERROR   = 2,
	PBFVS_PAUSED  = 3,
	PBFVS_PARTIAL = 4,
};


#define VSCLASS_COMBOBOXSTYLE	L"COMBOBOXSTYLE"
#define VSCLASS_COMBOBOX	L"COMBOBOX"

enum COMBOBOXPARTS
{
	CP_DROPDOWNBUTTON        = 1,
	CP_BACKGROUND            = 2,
	CP_TRANSPARENTBACKGROUND = 3,
	CP_BORDER                = 4,
	CP_READONLY              = 5,
	CP_DROPDOWNBUTTONRIGHT   = 6,
	CP_DROPDOWNBUTTONLEFT    = 7,
	CP_CUEBANNER             = 8,
};

#define COMBOBOXSTYLEPARTS COMBOBOXPARTS;

enum COMBOBOXSTYLESTATES
{
	CBXS_NORMAL   = 1,
	CBXS_HOT      = 2,
	CBXS_PRESSED  = 3,
	CBXS_DISABLED = 4,
};

enum DROPDOWNBUTTONRIGHTSTATES
{
	CBXSR_NORMAL   = 1,
	CBXSR_HOT      = 2,
	CBXSR_PRESSED  = 3,
	CBXSR_DISABLED = 4,
};

enum DROPDOWNBUTTONLEFTSTATES
{
	CBXSL_NORMAL   = 1,
	CBXSL_HOT      = 2,
	CBXSL_PRESSED  = 3,
	CBXSL_DISABLED = 4,
};

enum TRANSPARENTBACKGROUNDSTATES
{
	CBTBS_NORMAL   = 1,
	CBTBS_HOT      = 2,
	CBTBS_DISABLED = 3,
	CBTBS_FOCUSED  = 4,
};

enum BORDERSTATES
{
	CBB_NORMAL   = 1,
	CBB_HOT      = 2,
	CBB_FOCUSED  = 3,
	CBB_DISABLED = 4,
};

enum READONLYSTATES
{
	CBRO_NORMAL   = 1,
	CBRO_HOT      = 2,
	CBRO_PRESSED  = 3,
	CBRO_DISABLED = 4,
};

enum CUEBANNERSTATES
{
	CBCB_NORMAL   = 1,
	CBCB_HOT      = 2,
	CBCB_PRESSED  = 3,
	CBCB_DISABLED = 4,
};


#define VSCLASS_LISTBOXSTYLE L"LISTBOXSTYLE"
#define VSCLASS_LISTBOX      L"LISTBOX"

enum LISTBOXPARTS
{
	LBCP_BORDER_HSCROLL  = 1,
	LBCP_BORDER_HVSCROLL = 2,
	LBCP_BORDER_NOSCROLL = 3,
	LBCP_BORDER_VSCROLL  = 4,
	LBCP_ITEM            = 5,
};

#define LISTBOXSTYLEPARTS LISTBOXPARTS;

enum BORDER_HSCROLLSTATES
{
	LBPSH_NORMAL   = 1,
	LBPSH_FOCUSED  = 2,
	LBPSH_HOT      = 3,
	LBPSH_DISABLED = 4,
};

enum BORDER_HVSCROLLSTATES
{
	LBPSHV_NORMAL   = 1,
	LBPSHV_FOCUSED  = 2,
	LBPSHV_HOT      = 3,
	LBPSHV_DISABLED = 4,
};

enum BORDER_NOSCROLLSTATES
{
	LBPSN_NORMAL   = 1,
	LBPSN_FOCUSED  = 2,
	LBPSN_HOT      = 3,
	LBPSN_DISABLED = 4,
};

enum BORDER_VSCROLLSTATES
{
	LBPSV_NORMAL   = 1,
	LBPSV_FOCUSED  = 2,
	LBPSV_HOT      = 3,
	LBPSV_DISABLED = 4,
};

enum ITEMSTATES
{
	LBPSI_HOT              = 1,
	LBPSI_HOTSELECTED      = 2,
	LBPSI_SELECTED         = 3,
	LBPSI_SELECTEDNOTFOCUS = 4,
};


#endif // #ifndef __VSSTYLE_H__


#endif // #ifdef _MSC_VER




// XP or later

typedef HTHEME           (WINAPI *n_uxtheme_OpenThemeData                        )( HWND hwnd, LPCWSTR pszClassList );
typedef HRESULT          (WINAPI *n_uxtheme_CloseThemeData                       )( HTHEME hTheme );
typedef HRESULT          (WINAPI *n_uxtheme_DrawThemeBackground                  )( HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT *pRect, const RECT *pClipRect );
typedef HRESULT          (WINAPI *n_uxtheme_DrawThemeIcon                        )( HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT *pRect, HIMAGELIST himl, int iImageIndex );
typedef HRESULT          (WINAPI *n_uxtheme_DrawThemeText                        )( HTHEME hTheme, HDC hdc, int iPartId, int iStateId, LPCWSTR pszText, int iCharCount, DWORD dwTextFlags, DWORD dwTextFlags2, LPCRECT pRect );
typedef HRESULT          (WINAPI *n_uxtheme_GetThemeMetric                       )( HTHEME hTheme, HDC hdc, int iPartId, int iStateId, int iPropId, int *piVal );
typedef HRESULT          (WINAPI *n_uxtheme_GetThemeBackgroundContentRect        )( HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT*, RECT* );
typedef HBRUSH           (WINAPI *n_uxtheme_GetThemeSysColorBrush                )( HTHEME hTheme, int iColorID );
typedef DWORD            (WINAPI *n_uxtheme_GetThemeAppProperties                )( VOID );
typedef BOOL             (WINAPI *n_uxtheme_IsThemeBackgroundPartiallyTransparent)( HTHEME hTheme, int iPartId, int iStateId );
typedef HRESULT          (WINAPI *n_uxtheme_DrawThemeParentBackground            )( HWND hwnd, HDC hdc, const RECT *prc );


// Vista or later

typedef HPAINTBUFFER     (WINAPI *n_uxtheme_BeginBufferedPaint                   )( HDC hdcTarget, const RECT *prcTarget, BP_BUFFERFORMAT dwFormat, BP_PAINTPARAMS *pPaintParams, HDC *phdc );
typedef HRESULT          (WINAPI *n_uxtheme_EndBufferedPaint                     )( HPAINTBUFFER hBufferedPaint, BOOL fUpdateTarget );
typedef HRESULT          (WINAPI *n_uxtheme_DrawThemeTextEx                      )( HTHEME hTheme, HDC hdc, int iPartId, int iStateId, LPCWSTR pszText, int iCharCount, DWORD dwFlags, LPCRECT pRect, DTTOPTS *pOptions );
typedef HRESULT          (WINAPI *n_uxtheme_BufferedPaintInit                    )( VOID );
typedef HRESULT          (WINAPI *n_uxtheme_BufferedPaintUnInit                  )( VOID );
typedef HANIMATIONBUFFER (WINAPI *n_uxtheme_BeginBufferedAnimation               )( HWND hwnd, HDC hdcTarget, const RECT *rcTarget, BP_BUFFERFORMAT dwFormat, BP_PAINTPARAMS *pPaintParams, BP_ANIMATIONPARAMS *pAnimationParams, HDC *phdcFrom, HDC *phdcTo );
typedef HRESULT          (WINAPI *n_uxtheme_EndBufferedAnimation                 )( HANIMATIONBUFFER hbpAnimation, BOOL fUpdateTarget );
typedef HRESULT          (WINAPI *n_uxtheme_GetThemeTransitionDuration           )( HTHEME hTheme, int iPartId, int iStateIdFrom, int iStateIdTo, int iPropId, DWORD *pdwDuration );
typedef BOOL             (WINAPI *n_uxtheme_BufferedPaintRenderAnimation         )( HWND hwnd, HDC hdcTarget );
typedef HRESULT          (WINAPI *n_uxtheme_BufferedPaintStopAllAnimations       )( HWND hwnd );


typedef struct {

	bool                                            onoff;

	HMODULE                                         hmodule;
	HTHEME                                          htheme;

	bool                                            whistler;
	n_uxtheme_OpenThemeData                         OpenThemeData;
	n_uxtheme_CloseThemeData                        CloseThemeData;
	n_uxtheme_DrawThemeBackground                   DrawThemeBackground;
	n_uxtheme_DrawThemeIcon                         DrawThemeIcon;
	n_uxtheme_DrawThemeText                         DrawThemeText;
	n_uxtheme_GetThemeMetric                        GetThemeMetric;
	n_uxtheme_GetThemeBackgroundContentRect         GetThemeBackgroundContentRect;
	n_uxtheme_GetThemeSysColorBrush                 GetThemeSysColorBrush;
	n_uxtheme_GetThemeAppProperties                 GetThemeAppProperties;
	n_uxtheme_IsThemeBackgroundPartiallyTransparent IsThemeBackgroundPartiallyTransparent;
	n_uxtheme_DrawThemeParentBackground             DrawThemeParentBackground;

	bool                                            longhorn;
	n_uxtheme_BeginBufferedPaint                    BeginBufferedPaint;
	n_uxtheme_EndBufferedPaint                      EndBufferedPaint;
	n_uxtheme_DrawThemeTextEx                       DrawThemeTextEx;
	n_uxtheme_BufferedPaintInit                     BufferedPaintInit;
	n_uxtheme_BufferedPaintUnInit                   BufferedPaintUnInit;
	n_uxtheme_BeginBufferedAnimation                BeginBufferedAnimation;
	n_uxtheme_EndBufferedAnimation                  EndBufferedAnimation;
	n_uxtheme_GetThemeTransitionDuration            GetThemeTransitionDuration;
	n_uxtheme_BufferedPaintRenderAnimation          BufferedPaintRenderAnimation;
	n_uxtheme_BufferedPaintStopAllAnimations        BufferedPaintStopAllAnimations;

} n_uxtheme;




bool
n_uxtheme_is_running( n_uxtheme *u )
{

	if ( u           == NULL  ) { return false; }
	if ( u->whistler == false ) { return false; }


	// [!] : IsThemeActive(), IsAppThemed()
	//
	//	both are true => ON
	//
	//	1 : display property's preview
	//	2 : "no visual style" setting


	int ret = u->GetThemeAppProperties() & STAP_ALLOW_CONTROLS;


	u->onoff = ( ret != 0 );


	return u->onoff;
}

void
n_uxtheme_zero( n_uxtheme *u )
{

	if ( u == NULL ) { return; }


	ZeroMemory( u, sizeof( n_uxtheme ) );


	return;
}

void
n_uxtheme_init( n_uxtheme *u, HWND hwnd, LPCWSTR pszClassList )
{

	if ( u == NULL ) { return; }


	// [!] : you need to free manually

	if ( u->hmodule != NULL ) { return; }


	// [!] : for compatibility layer support

	if ( false == n_sysinfo_version_xp_or_later() ) { return; }


	int check;


	u->hmodule = LoadLibrary( n_posix_literal( "uxtheme.dll" ) );
	if ( u->hmodule == NULL ) { return; }

	u->OpenThemeData                         = (void*) GetProcAddress( u->hmodule, "OpenThemeData"                         );
	u->CloseThemeData                        = (void*) GetProcAddress( u->hmodule, "CloseThemeData"                        );
	u->DrawThemeBackground                   = (void*) GetProcAddress( u->hmodule, "DrawThemeBackground"                   );
	u->DrawThemeIcon                         = (void*) GetProcAddress( u->hmodule, "DrawThemeIcon"                         );
	u->DrawThemeText                         = (void*) GetProcAddress( u->hmodule, "DrawThemeText"                         );
	u->GetThemeMetric                        = (void*) GetProcAddress( u->hmodule, "GetThemeMetric"                        );
	u->GetThemeBackgroundContentRect         = (void*) GetProcAddress( u->hmodule, "GetThemeBackgroundContentRect"         );
	u->GetThemeSysColorBrush                 = (void*) GetProcAddress( u->hmodule, "GetThemeSysColorBrush"                 );
	u->GetThemeAppProperties                 = (void*) GetProcAddress( u->hmodule, "GetThemeAppProperties"                 );
	u->IsThemeBackgroundPartiallyTransparent = (void*) GetProcAddress( u->hmodule, "IsThemeBackgroundPartiallyTransparent" );
	u->DrawThemeParentBackground             = (void*) GetProcAddress( u->hmodule, "DrawThemeParentBackground"             );


	check = 0;

	if ( u->OpenThemeData                         == NULL ) { check++; }
	if ( u->CloseThemeData                        == NULL ) { check++; }
	if ( u->DrawThemeBackground                   == NULL ) { check++; }
	if ( u->DrawThemeIcon                         == NULL ) { check++; }
	if ( u->DrawThemeText                         == NULL ) { check++; }
	if ( u->GetThemeMetric                        == NULL ) { check++; }
	if ( u->GetThemeBackgroundContentRect         == NULL ) { check++; }
	if ( u->GetThemeSysColorBrush                 == NULL ) { check++; }
	if ( u->IsThemeBackgroundPartiallyTransparent == NULL ) { check++; }
	if ( u->DrawThemeParentBackground             == NULL ) { check++; }

	if ( check == 0 ) { u->whistler = true; } else { return; }


	u->htheme = u->OpenThemeData( hwnd, pszClassList );
	if ( u->htheme == NULL ) { u->whistler = false; return; }

	u->BeginBufferedPaint                    = (void*) GetProcAddress( u->hmodule, "BeginBufferedPaint"                    );
	u->EndBufferedPaint                      = (void*) GetProcAddress( u->hmodule, "EndBufferedPaint"                      );
	u->DrawThemeTextEx                       = (void*) GetProcAddress( u->hmodule, "DrawThemeTextEx"                       );
	u->BufferedPaintInit                     = (void*) GetProcAddress( u->hmodule, "BufferedPaintInit"                     );
	u->BufferedPaintUnInit                   = (void*) GetProcAddress( u->hmodule, "BufferedPaintUnInit"                   );
	u->BeginBufferedAnimation                = (void*) GetProcAddress( u->hmodule, "BeginBufferedAnimation"                );
	u->EndBufferedAnimation                  = (void*) GetProcAddress( u->hmodule, "EndBufferedAnimation"                  );
	u->GetThemeTransitionDuration            = (void*) GetProcAddress( u->hmodule, "GetThemeTransitionDuration"            );
	u->BufferedPaintRenderAnimation          = (void*) GetProcAddress( u->hmodule, "BufferedPaintRenderAnimation"          );
	u->BufferedPaintStopAllAnimations        = (void*) GetProcAddress( u->hmodule, "BufferedPaintStopAllAnimations"        );


	check = 0;

	if ( u->DrawThemeTextEx                == NULL ) { check++; }
	if ( u->BufferedPaintInit              == NULL ) { check++; }
	if ( u->BufferedPaintUnInit            == NULL ) { check++; }
	if ( u->BeginBufferedAnimation         == NULL ) { check++; }
	if ( u->EndBufferedAnimation           == NULL ) { check++; }
	if ( u->GetThemeTransitionDuration     == NULL ) { check++; }
	if ( u->BufferedPaintRenderAnimation   == NULL ) { check++; }
	if ( u->BufferedPaintStopAllAnimations == NULL ) { check++; }

	if ( check == 0 ) { u->longhorn = true; }

	if ( u->longhorn )
	{
		u->BufferedPaintInit();
	}


	n_uxtheme_is_running( u );


	return;
}

void
n_uxtheme_exit( n_uxtheme *u, HWND hwnd )
{

	if ( u == NULL ) { return; }


	if ( u->whistler )
	{

		if ( u->longhorn )
		{
			u->BufferedPaintStopAllAnimations( hwnd );
			u->BufferedPaintUnInit();
		}

		u->CloseThemeData( u->htheme );

	}


	FreeLibrary( u->hmodule );


	n_uxtheme_zero( u );


	return;
}

#define N_UXTHEME_THEMENAME_CCH_MAX 100

void
n_uxtheme_themename( n_uxtheme *u, n_posix_char *str_ret )
{

	// [!] : VC++ 2017 : "cch" cannot be used as an array initializer

	const int cch = N_UXTHEME_THEMENAME_CCH_MAX;
	const int cb  = cch * sizeof( n_posix_char );


	// [x] : Vista or later only

	FARPROC n_GetCurrentThemeName           = GetProcAddress( u->hmodule, "GetCurrentThemeName" );
	FARPROC n_GetThemeDocumentationProperty = GetProcAddress( u->hmodule, "GetThemeDocumentationProperty" );

	if (
		( n_GetCurrentThemeName           != NULL )
		&&
		( n_GetThemeDocumentationProperty != NULL )
	)
	{

		// [!] : "Aero" will be returned

		n_posix_char str[ N_UXTHEME_THEMENAME_CCH_MAX ]; n_string_truncate( str );

		n_GetCurrentThemeName( str,cch, NULL,0, NULL,0 );
		n_GetThemeDocumentationProperty( str, L"ThemeName", str_ret, cch );

	} else {

		// [!] : "luna", "Royale", etc will be returned

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\ThemeManager" );
		n_posix_char *section = n_posix_literal( "DllName" );

		n_posix_char str[ N_UXTHEME_THEMENAME_CCH_MAX ]; n_string_zero( str, cch );

		n_registry_read( HKEY_CURRENT_USER, subkey, section, str, cb );

		ExpandEnvironmentStrings( str, str, cch );

		n_string_path_name( str, str_ret );
		n_string_path_ext_del( str_ret );

	}
//n_posix_debug_literal( "%s", str_ret );


	return;
}

HFONT
n_uxtheme_hfont( n_uxtheme *u, int tmt )
{

	if ( u == NULL ) { return NULL; }


	// [Needed] : n_win_font_exit( hfont );


	HFONT hfont = NULL;

	if ( ( u->longhorn )||( u->whistler ) )
	{

		FARPROC func = GetProcAddress( u->hmodule, "GetThemeSysFont" );


		LOGFONTW lfw; ZeroMemory( &lfw, sizeof( LOGFONTW ) );

		func( u->htheme, tmt, &lfw );

/*
		// [!] : dpi aware == false needs this
		HDC hdc = GetDC( NULL );
		lfw.lfHeight = -MulDiv( lfw.lfHeight, GetDeviceCaps( hdc, LOGPIXELSY ), 72 );
		ReleaseDC( NULL, hdc );
*/

#ifdef UNICODE

		LOGFONT lf = lfw;

#else // #ifndef UNICODE

		LOGFONT lf; n_memory_copy( &lfw, &lf, sizeof( LOGFONT ) );

		n_posix_char *s = n_posix_unicode2ansi( lfw.lfFaceName );

		n_string_copy( s, lf.lfFaceName );

		n_memory_free( s );

#endif // #ifndef UNICODE


		hfont = n_win_font_logfont2hfont( &lf );

	} else {

		size_t           cb = sizeof( NONCLIENTMETRICS );
		NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

		ncm.cbSize = cb;
		SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );

		if ( tmt == TMT_CAPTIONFONT )
		{
			hfont = n_win_font_logfont2hfont( &ncm.lfCaptionFont );
		} else
		if ( tmt == TMT_SMALLCAPTIONFONT )
		{
			hfont = n_win_font_logfont2hfont( &ncm.lfSmCaptionFont );
		} else
		if ( tmt == TMT_MENUFONT )
		{
			hfont = n_win_font_logfont2hfont( &ncm.lfMenuFont );
		} else
		if ( tmt == TMT_STATUSFONT )
		{
			hfont = n_win_font_logfont2hfont( &ncm.lfStatusFont );
		} else
		if ( tmt == TMT_MSGBOXFONT )
		{
			hfont = n_win_font_logfont2hfont( &ncm.lfMessageFont );
		} else
		if ( tmt == TMT_ICONTITLEFONT )
		{

			LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );

			SystemParametersInfo
			(
				SPI_GETICONTITLELOGFONT,
				sizeof( LOGFONT ),
  				&lf, 0
			);

			hfont = n_win_font_logfont2hfont( &lf );

		}

	}


	return hfont;
}

static COLORREF n_uxtheme_draw_text_color         = 0;
static bool     n_uxtheme_draw_text_contour_onoff = false;
static bool     n_uxtheme_draw_text_glow_onoff    = false;

void
n_uxtheme_draw_text( n_uxtheme *u, HWND hgui, HDC hdc, RECT *rect, int part, int state, int dt, int tmt, bool dwm )
{

	// [ Mechanism ]
	//
	//	[ Classic Theme ]
	//
	//	"part"  : not used
	//	"state" : ODS_*


	// [!] : WinXP or later : ANSI + DBCS : character count will be returned


	if (    u == NULL ) { return; }
	if ( rect == NULL ) { return; }


	s32 scale = n_win_dpi( hgui ) / 96;


	// [!] : font needs to be themed

	HFONT hf  = n_uxtheme_hfont( u, tmt );
	HFONT phf = SelectObject( hdc, hf );

	if ( ( u->onoff )&&( n_win_darkmode_onoff == false ) )
	{

		int      wcch = GetWindowTextLengthW( hgui );
		wchar_t *wstr = n_memory_new_closed( ( wcch + 1 ) * sizeof( wchar_t ) ); GetWindowTextW( hgui, wstr, wcch + 1 );

		if ( ( u->longhorn )&&( dwm ) )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), "1" );

			// [!] : text will be upside-down


			if ( n_uxtheme_draw_text_contour_onoff )
			{

				DTTOPTS opts; ZeroMemory( &opts, sizeof( DTTOPTS ) );

				opts.dwSize  = sizeof( DTTOPTS );
				opts.dwFlags = DTT_COMPOSITED | DTT_TEXTCOLOR;
				opts.crText  = RGB( 255,255,255 );

				s32 x = -scale;
				s32 y = -scale;
				while( 1 )
				{

					RECT r = (*rect); n_win_rect_move( &r, x,y );
					u->DrawThemeTextEx( u->htheme, hdc, part,state, wstr,-1, dt, &r, &opts );

					x++;
					if ( x > scale )
					{
						x = -scale;
						y++;
						if ( y > scale ) { break; }
					}
				}

			}


			// [x] : not working : opts.iFontPropId

			DTTOPTS opts; ZeroMemory( &opts, sizeof( DTTOPTS ) );

			opts.dwSize  = sizeof( DTTOPTS );
			opts.dwFlags = DTT_COMPOSITED;

			//opts.dwFlags          = opts.dwFlags | DTT_BORDERCOLOR | DTT_BORDERSIZE;
			//opts.crBorder         = RGB( 1, 1, 1 );
			//opts.iBorderSize      = 2;

			//opts.dwFlags          = opts.dwFlags | DTT_SHADOWCOLOR | DTT_SHADOWTYPE;
			//opts.crShadow         = RGB( 1, 1, 1 );
			//opts.iTextShadowType  = TST_CONTINUOUS;

			//opts.dwFlags          = opts.dwFlags | DTT_SHADOWOFFSET;
			//opts.ptShadowOffset.x = 2;
			//opts.ptShadowOffset.y = 2;

			//opts.dwFlags          = opts.dwFlags | DTT_APPLYOVERLAY;
			//opts.fApplyOverlay    = true;

			if ( n_uxtheme_draw_text_color != 0 )
			{
				opts.dwFlags = opts.dwFlags | DTT_TEXTCOLOR;
				opts.crText  = n_uxtheme_draw_text_color;
			}

			if ( n_uxtheme_draw_text_glow_onoff )
			{
				opts.dwFlags   = opts.dwFlags | DTT_GLOWSIZE;
				opts.iGlowSize = 8 * scale;
			}


			u->DrawThemeTextEx( u->htheme, hdc, part,state, wstr,-1, dt, rect, &opts );


		} else {
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), "2" );

			u->DrawThemeText( u->htheme, hdc, part,state, wstr,-1, dt,0, rect );

		}

		n_memory_free_closed( wstr );

	} else {
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hgui ), "3" );

		SetBkMode( hdc, TRANSPARENT );

		int           cch = GetWindowTextLength( hgui );
		n_posix_char *str = n_string_new( cch ); GetWindowText( hgui, str, cch + 1 );

		if ( state & ODS_DISABLED )
		{

			RECT r = (*rect); n_win_rect_move( &r, scale,scale );

			SetTextColor( hdc, GetSysColor( COLOR_3DHILIGHT ) );
			DrawText( hdc, str,cch,   &r, dt );

			SetTextColor( hdc, GetSysColor( COLOR_BTNSHADOW ) );
			DrawText( hdc, str,cch, rect, dt );

		} else {

			SetTextColor( hdc, n_win_darkmode_systemcolor( COLOR_BTNTEXT ) );
			DrawText( hdc, str,cch, rect, dt );

		}

		n_string_free( str );

	}

	n_win_font_exit( SelectObject( hdc, phf ) );


	return;
}


#endif // _H_NONNON_WIN32_UXTHEME

