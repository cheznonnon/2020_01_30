// nonnon win scroll
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_SCROLL
#define _H_NONNON_WIN32_WIN_SCROLL




#include "../neutral/string.c"

#include "./win/control.c"
#include "./win/cursor.c"
#include "./win/style.c"




// internal
DWORD
n_win_scroll_sbs( HWND hgui )
{

	// [!] : SB_CTL only

	const DWORD mask = 1;

	return mask & n_win_style_get( hgui );
}

void
n_win_scroll_init( HWND hwnd, int pos,int page, int min,int max, int type )
{

	// [Mechanism]
	//
	//	type = 0 : X : SB_HORZ
	//	type = 1 : Y : SB_VERT
	//	type = 2 : - : SB_CTL
	//
	//	redrawing needs : ( Window => ) Client Area => Scroll Bars


	// [Needed] : max - 1 : magic number : this is not step value

	SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, min, max - 1, page, pos, 0 };


	if ( type == SB_CTL )
	{
		si.nMax += page;
	}

	SetScrollInfo( hwnd, type, &si, false );


	return;
}

void
n_win_scroll_draw( HWND hwnd, int type )
{

	SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };


	GetScrollInfo( hwnd, type, &si       );
	SetScrollInfo( hwnd, type, &si, true );


	return;
}

#define n_win_scroll_refresh( hwnd, type ) n_win_scroll_sendmsg( hwnd, type, SB_ENDSCROLL, 0 )

void
n_win_scroll_sendmsg( HWND hwnd_target, int type, int sb, int param )
{

	HWND hwnd = NULL;
	HWND hgui = NULL;
	UINT wm   = WM_NULL;

	if ( type == SB_VERT )
	{

		hwnd = hwnd_target;
		hgui = NULL;
		wm   = WM_VSCROLL;

	} else
	if ( type == SB_HORZ )
	{

		hwnd = hwnd_target;
		hgui = NULL;
		wm   = WM_HSCROLL;

	} else
	if ( type == SB_CTL )
	{

		hwnd = GetParent( hwnd_target );
		hgui = hwnd_target;

		DWORD sbs = n_win_scroll_sbs( hgui );

		if ( sbs == SBS_VERT ) { wm = WM_VSCROLL; } else
		if ( sbs == SBS_HORZ ) { wm = WM_HSCROLL; } else { return; }

	} else
	//
	{
		return;
	}


	n_win_message_send( hwnd, wm, MAKEWPARAM( sb, param ), hgui );


	return;
}

#define n_win_scroll_position_get GetScrollPos

void
n_win_scroll_position_set( HWND hwnd, int type, int delta )
{

	// [x] : this module doesn't function in some cases

	// [x] : this has only 16bit range
	//
	//	edit controls ignore SetScrollInfo()


	int pos = n_win_scroll_position_get( hwnd, type ) + delta;


	// [Needed] : clipping

	pos = n_posix_max( 0, pos );


	n_win_scroll_sendmsg( hwnd, type, SB_THUMBTRACK, pos );


	return;
}

void
n_win_scroll_position_updown( HWND hwnd, int type, int delta )
{

	// [x] : this module doesn't function in some cases


	if ( delta == 0 ) { return; }

	if ( SBS_HORZ == n_win_scroll_sbs( hwnd ) ) { delta *= -1; }

	if ( delta < 0 )
	{
		n_win_scroll_sendmsg( hwnd, type, SB_LINEUP,   0 );
	} else {
		n_win_scroll_sendmsg( hwnd, type, SB_LINEDOWN, 0 );
	}


	return;
}

int
n_win_scroll_wheeldelta( WPARAM wparam, UINT unit )
{

	// [!] : also see n_win_msgloop() @ win32/win.c

	n_posix_char *class = n_posix_literal( "MouseZ" );
	n_posix_char *title = n_posix_literal( "Magellan MSWHEEL" );

	HWND hwnd  = FindWindow( class, title );
	UINT msg   = RegisterWindowMessage( n_posix_literal( "MSH_WHEELSUPPORT_MSG" ) );	
	bool onoff = n_win_message_send( hwnd, msg, 0, 0 );

	int delta = (s16) HIWORD( wparam ) / WHEEL_DELTA;
	if ( delta == 0 ) { return 0; } else { delta *= -1; }

	if ( onoff )
	{
//n_posix_debug_literal( "IntelliPoint is ON" );

		if ( unit == 0 )
		{

			UINT msg_scrol_lines = RegisterWindowMessage( n_posix_literal( "MSH_SCROLL_LINES_MSG" ) );

			unit = n_win_message_send( hwnd, msg_scrol_lines, 0, 0 );

		}

	} else {
//n_posix_debug_literal( "IntelliPoint is OFF" );

		if ( unit == 0 )
		{
			SystemParametersInfo( SPI_GETWHEELSCROLLLINES, 0, &unit, 0 );
		}

	}


	return unit * delta;
}

int
n_win_scroll_msg( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, int pos, int step, int type )
{
//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) hwnd, (int) lparam );


	// [!] : si.nMax - si.nPage + 1 : see n_win_scroll_init()

	HWND h;

	if ( type != SB_CTL )
	{
		h = hwnd;
	} else {
		h = (HWND) lparam;
	}


	SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };
	GetScrollInfo( h, type, &si );

	si.nPos  = pos;
	int stop = si.nMax - si.nPage + 1;


	if ( msg != WM_MOUSEWHEEL )
	{

		int sb = LOWORD( wparam );


		if ( sb == SB_LINEUP     ) { si.nPos -= step;     } else
		if ( sb == SB_LINEDOWN   ) { si.nPos += step;     } else
		if ( sb == SB_PAGEUP     ) { si.nPos -= si.nPage; } else
		if ( sb == SB_PAGEDOWN   ) { si.nPos += si.nPage; } else
		if ( sb == SB_TOP        ) { si.nPos  = si.nMin;  } else
		if ( sb == SB_BOTTOM     ) { si.nPos  = si.nMax;  } else
		if ( sb == SB_THUMBTRACK )
		{

			// [!] : this cannot handle minus value
			//
			//	you need re-map like this
			//	-100 :    0 : +100
			//	   0 : +100 : +200

			// [!] : 16bit only : si.nPos = HIWORD( wparam );

			si.nPos = si.nTrackPos;

		}

	} else {

		si.nPos += n_win_scroll_wheeldelta( wparam, step );

	}

	if ( si.nPos < si.nMin ) { si.nPos = si.nMin; }
	if ( si.nPos > stop    ) { si.nPos =    stop; }


	SetScrollInfo( h, type, &si, false );


	return si.nPos;
}

void
n_win_scroll_msg_redirector( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( msg != WM_MOUSEWHEEL ) { return; }


	HWND hwnd_scroll = n_win_cursor2hwnd();


	// [!] : SB_CTL only

	if ( false == n_win_class_is_same_literal( hwnd_scroll, "ScrollBar" ) ) { return; }


	// [!] : don't use parameter "hwnd"
	//
	//	WM_MOUSEMOVE or WM_NCMOUSEMOVE don't come when a cursor is moved quickly

	HWND hwnd_target = GetParent( hwnd_scroll );


	// [!] : for wheeling on taskbar

	DWORD pid_1, pid_2;

	GetWindowThreadProcessId( hwnd,        &pid_1 );
	GetWindowThreadProcessId( hwnd_target, &pid_2 );

	if ( pid_1 != pid_2 ) { return; }


	n_win_scroll_position_updown( hwnd_scroll, SB_CTL, n_win_scroll_wheeldelta( wparam, 1 ) );


	return;
}


#endif // _H_NONNON_WIN32_WIN_SCROLL

