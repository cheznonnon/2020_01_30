// Nonnon Direct2D1 Bridge DLL Caller
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : see @toybox/directx/Nonnon Direct2D1 DLL for details


// [ Mechanism ]
//
//	crash when position and size are not clipped
//	performance will slightly regain when DWM is ON
//
//
//	[ WM_CREATE and WM_CLOSE ]
//
//	n_direct2d_init()
//	n_direct2d_exit()
//
//
//	[ WM_PAINT ]
//
//	n_direct2d_make() : make a back-buffer as D2D1Bitmap
//
//	n_direct2d_copy() : copy n_bmp to D2D1Bitmap
//	n_direct2d_draw() : draw D2D1Bitmap
//
//	n_direct2d_sync() : partial copy and draw
//
//
//	[ Backward Compatibility ]
//
//	if ( n_direct2d_is_on() ) { /* ON */ } else { /* Off : Fallback to GDI */ }




#ifndef _H_NONNON_WIN32_GAME_DIRECT2D
#define _H_NONNON_WIN32_GAME_DIRECT2D




#include "../neutral/bmp/all.c"




typedef struct {

	HMODULE hmod;
	FARPROC init;
	FARPROC exit;
	FARPROC make;
	FARPROC copy;
	FARPROC draw;

} n_direct2d;


static n_direct2d n_direct2d_instance = { NULL, NULL,NULL,NULL,NULL,NULL };




#define n_direct2d_zero( p ) n_memory_zero( p, sizeof( n_direct2d ) )

#define n_direct2d_is_on() ( n_direct2d_instance.hmod != NULL )

void
n_direct2d_exit( void )
{

	// [!] : FreeLibrary() crashes at exit in WndProc(), use WinMain() to free

	if ( n_direct2d_is_on() )
	{
		if ( n_direct2d_instance.exit ) { n_direct2d_instance.exit(); }
		FreeLibrary( n_direct2d_instance.hmod );
	}

	n_direct2d_zero( &n_direct2d_instance );


	return;
}

void
n_direct2d_init( void )
{

	n_direct2d_zero( &n_direct2d_instance );


	// [!] : Version Checker

	// [x] : dont use n_posix_stat_is_exist() false will be returned

	//bool is_exist = n_posix_stat_is_exist( n_posix_literal( "d2d1.dll" ) );

	HMODULE hmod = LoadLibrary( n_posix_literal( "d2d1.dll" ) );

	bool is_exist = ( hmod != NULL );

	FreeLibrary( hmod );

	if ( is_exist == false ) { return; }


	n_direct2d_instance.hmod = LoadLibrary( n_posix_literal( "Nonnon Direct2D1 DLL.dll" ) );
	n_direct2d_instance.init = GetProcAddress( n_direct2d_instance.hmod, "n_d2d1_init" );
	n_direct2d_instance.exit = GetProcAddress( n_direct2d_instance.hmod, "n_d2d1_exit" );
	n_direct2d_instance.make = GetProcAddress( n_direct2d_instance.hmod, "n_d2d1_bitmap_make" );
	n_direct2d_instance.copy = GetProcAddress( n_direct2d_instance.hmod, "n_d2d1_bitmap_copy" );
	n_direct2d_instance.draw = GetProcAddress( n_direct2d_instance.hmod, "n_d2d1_bitmap_draw" );


	bool error = false;

	if ( n_direct2d_instance.hmod == NULL ) { error = true; }
	if ( n_direct2d_instance.init == NULL ) { error = true; }
	if ( n_direct2d_instance.exit == NULL ) { error = true; }
	if ( n_direct2d_instance.make == NULL ) { error = true; }
	if ( n_direct2d_instance.copy == NULL ) { error = true; }
	if ( n_direct2d_instance.draw == NULL ) { error = true; }

	if ( error ) { n_direct2d_exit(); } else { n_direct2d_instance.init(); }


	return;
}


#define n_direct2d_make_empty( hwnd, sx,sy ) n_direct2d_make( hwnd, NULL, sx,sy )

void
n_direct2d_make( HWND hwnd, void *ptr, s32 sx, s32 sy )
{

	if ( n_direct2d_instance.make ) { n_direct2d_instance.make( hwnd, ptr, sx,sy ); }

	return;
}

void
n_direct2d_copy( HWND hwnd, void *ptr, s32 sx, s32 sy, s32 ox, s32 oy )
{

	if ( n_direct2d_instance.copy ) { n_direct2d_instance.copy( hwnd, ptr, sx,sy, ox,oy ); }

	return;
}

void
n_direct2d_draw( HWND hwnd, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( n_direct2d_instance.draw ) { n_direct2d_instance.draw( hwnd, x,y,sx,sy ); }

	return;
}

void
n_direct2d_sync( HWND hwnd, n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, s32 ox, s32 oy )
{

	RECT r; GetClientRect( hwnd, &r );

	s32 csx = r.right;
	s32 csy = r.bottom;

	n_direct2d_make_empty( hwnd, csx,csy );


	n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
	n_bmp_fastcopy( bmp, &b, x,y, sx,sy, 0,0 );

	n_direct2d_copy( hwnd, N_BMP_PTR( &b ),sx,sy, ox,oy );
	n_direct2d_draw( hwnd, ox,oy, sx,sy );

	n_bmp_free( &b );


	return;
}


#endif // _H_NONNON_WIN32_GAME_DIRECT2D

