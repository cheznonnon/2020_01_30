// Nonnon COM : Debugging System
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html



// [Mechanism]
//
//	N_COM_DEBUG_ONOFF
//
//	ON  : output to dialog or listbox
//	OFF : suppress silently




#ifndef _H_NONNON_WIN32_COM_DEBUG
#define _H_NONNON_WIN32_COM_DEBUG




#ifndef N_COM_DEBUG_ONOFF


// [Mechanism]
//
//	these macro will be empty
//	any string literals will be removed from code
//	for reducing EXE size


#define n_com_debug_guid2str( a,b )
#define n_com_debug_IUnknown_QueryInterface( a,b,c )
#define n_com_debug_IDispatch_Invoke( a,b,c,d,e,f,g,h,i )
#define n_com_debug_a( s )
#define n_com_debug_w( s )
#define n_com_debug_listbox_init( a )
#define N_COM_DEBUG_LISTBOX_SET_A( a )
#define N_COM_DEBUG_LISTBOX_SET_W( a )
//#define n_com_debug_listbox_set( a,b ) // internal


#else // #ifndef N_COM_DEBUG_ONOFF




#include "../../win32/win_scroll.c"


#include <oaidl.h>




void
n_com_debug_a( char *str )
{

	MessageBoxA( NULL, str, "DEBUG", 0 );


	return;
}

void
n_com_debug_w( wchar_t *str )
{

	MessageBoxW( NULL, str, L"DEBUG", 0 );


	return;
}




void
n_com_debug_guid2str( GUID guid, n_posix_char *ret )
{

	n_posix_sprintf_literal
	(
		ret,
		"{%08lx-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
		guid.Data1,
		guid.Data2,
		guid.Data3,
		guid.Data4[ 0 ],
		guid.Data4[ 1 ],
		guid.Data4[ 2 ],
		guid.Data4[ 3 ],
		guid.Data4[ 4 ],
		guid.Data4[ 5 ],
		guid.Data4[ 6 ],
		guid.Data4[ 7 ]
	);


	return;
}

void
n_com_debug_IUnknown_QueryInterface( const void *_this, REFIID iid, void **ppvObject )
{

	// [!] : Calling Sequence
	//
	// 1   : {00000003-0000-0000-c0000-000000000046} : IMarshal
	// 2   : {00000003-0000-0000-c0000-000000000046} : IMarshal
	// 3   : {0000001b-0000-0000-c0000-000000000046} : ???
	// 4   : {00000000-0000-0000-c0000-000000000046} : IUnknown
	// 5   : {00000018-0000-0000-c0000-000000000046} : IStdMarshalInfo
	// 6   : {00000019-0000-0000-c0000-000000000046} : IExternalConnection
	// 7   : {00000018-0000-0000-c0000-000000000046} : IStdMarshalInfo
	// 8   : {00000018-0000-0000-c0000-000000000046} : IStdMarshalInfo


	n_posix_debug_literal
	(
		"QueryInterface"
		"\n"
		"{%08lx-%04x-%04x-%02x%02x-%02x %02x %02x %02x %02x %02x}"
		"\n",
		iid->Data1, iid->Data2, iid->Data3,
		iid->Data4[0], iid->Data4[1], iid->Data4[2], iid->Data4[3],
		iid->Data4[4], iid->Data4[5], iid->Data4[6], iid->Data4[7]
	);


	return;
}

void
n_com_debug_IDispatch_Invoke
(
	const void   *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{

	n_posix_debug_literal
	(
		"Invoke \n"
		"DISPID \t %d \n"
		"PARAM0 \t %d \n"
		"PARAM1 \t %d \n"
		"PARAM2 \t %d \n"
		"PARAM3 \t %d \n"
		"PARAM4 \t %d \n"
		"PARAM5 \t %d \n"
		"PARAM6 \t %d \n"
		"PARAM7 \t %d \n",
		(int) dispIdMember,
		V_VT( &pDispParams->rgvarg[ 0 ] ),
		V_VT( &pDispParams->rgvarg[ 1 ] ),
		V_VT( &pDispParams->rgvarg[ 2 ] ),
		V_VT( &pDispParams->rgvarg[ 3 ] ),
		V_VT( &pDispParams->rgvarg[ 4 ] ),
		V_VT( &pDispParams->rgvarg[ 5 ] ),
		V_VT( &pDispParams->rgvarg[ 6 ] ),
		V_VT( &pDispParams->rgvarg[ 7 ] )
	);


	return;
}




static HWND n_com_debug_listbox_hwnd = NULL;

void
n_com_debug_listbox_init( HWND hwnd )
{

	HWND h = CreateWindowEx
	(
		WS_EX_CLIENTEDGE,
		n_posix_literal( "LISTBOX" ),
		n_posix_literal( "" ),
		WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_NOTIFY,
		0,0, 0,0,
		hwnd,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL
	);


	n_win_message_send( h, WM_SETFONT, (WPARAM) GetStockObject( DEFAULT_GUI_FONT ), false );


	n_com_debug_listbox_hwnd = h;


	return;
}

#define N_COM_DEBUG_LISTBOX_SET_A( s ) n_com_debug_listbox_set( s, NULL )
#define N_COM_DEBUG_LISTBOX_SET_W( s ) n_com_debug_listbox_set( NULL, s )

// internal
void
n_com_debug_listbox_set( void *ansi, void *unicode )
{

	HWND h = n_com_debug_listbox_hwnd;
	if ( h == NULL ) { return; }


	n_posix_char *s = NULL;

#ifdef UNICODE

	if ( ansi != NULL )
	{
		s = n_posix_ansi2unicode( ansi );
	} else {
		s = n_string_carboncopy( unicode );
	}

#else // #ifdef UNICODE

	if ( ansi != NULL )
	{
		s = n_string_carboncopy( ansi );
	} else {
		s = n_posix_unicode2ansi( unicode );
	}

#endif // #ifdef UNICODE


	n_win_message_send( h, LB_ADDSTRING, 0, (LPARAM) s );
	n_win_scroll_position_set( h, SB_VERT, 1 );


	n_memory_free( s );


	return;
}


#endif // #ifndef N_COM_DEBUG_ONOFF




#endif // _H_NONNON_WIN32_COM_DEBUG

