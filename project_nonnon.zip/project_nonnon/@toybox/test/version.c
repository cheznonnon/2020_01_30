



#include <windows.h>




int
main( void )
{

	OSVERSIONINFO osver;

	char str[ 1024 ];


	ZeroMemory( &osver, sizeof( OSVERSIONINFO ) );
	osver.dwOSVersionInfoSize = sizeof( OSVERSIONINFO );

	GetVersionEx( &osver );


	wsprintf
	(
		str,
		"MajorVersion \t %lu \n"
		"MinorVersion \t %lu \n"
		"BuildNumber  \t %lu \n"
		"PlatformId   \t %lu \n"
		"CSDVersion   \t %s",
		osver.dwMajorVersion,
		osver.dwMinorVersion,
		osver.dwBuildNumber,
		osver.dwPlatformId,
		osver.szCSDVersion
	);

	MessageBoxA( NULL, str, "DEBUG", 0 );


	return 0;
}

